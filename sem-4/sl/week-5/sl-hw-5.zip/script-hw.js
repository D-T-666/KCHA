// Task 1

let inputA = document.createElement("input");
let inputB = document.createElement("input");
inputA.type = "number";
inputB.type = "number";
let multiply = document.createElement("button");
multiply.innerText = "multiply";
multiply.addEventListener("click", (e) => {
    e.preventDefault();
    result.innerText = inputA.value * inputB.value;
})
let divide = document.createElement("button");
divide.innerText = "divide";
divide.addEventListener("click", (e) => {
    e.preventDefault();
    result.innerText = inputA.value / inputB.value;
})
let result = document.createElement("span");
let div = document.createElement("div");
div.appendChild(inputA);
div.appendChild(inputB);
div.appendChild(multiply);
div.appendChild(divide);
div.appendChild(result);
document.body.appendChild(div);

// Task 2

function average(marks) {
    let total = 0
    for (let mark of marks) {
        total += mark;
    }
    let avg = total / marks.length;

    if (avg <= 50) return "F";
    if (avg <= 60) return "E";
    if (avg <= 70) return "D";
    if (avg <= 80) return "C";
    if (avg <= 90) return "B";
    if (avg <=100) return "A";
    return "A+";
}

console.log(average([90, 10, 50, 100, 100]));

// Task 3

let user = {
    name: "Donald Knuth",
    hobbies: {
        indoor: ["dancing", "painting", "knitting"],
        outdoor: [],
    },
    age: 69,
    music_genre: "Bop"
};

console.log(user.name);
console.log(user.hobbies.indoor);
let age = user.age;
console.log(age);
console.log(user.music_genre);

// Task 4

let student = {
    age: 20,
    name: "Giorgi"
};

student.age++;
student.grade = "A-";

// console.log(student);

// Task 5

function invoice(amt, isWholesale) {
    return amt * (isWholesale ? 0.8 : 0.9);
}

// a shorter variant
// let i=(a,w)=>a*(9-w)/10;