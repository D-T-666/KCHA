let num = 29;
num += 99;
num -= 23;

let sentence = "I";
sentence += " am";
sentence += " hungry";
// მართლა მშია ისე, რა დამთხვევაა

function classifySize(num) {
    if (num >= 100) {
        console.log("LARGE");
    } else {
        console.log("SMALL");
    }
}

function sumtripple(a, b) {
    if (a == b) {
        return 6 * a;
    } else {
        return a + b;
    }
}